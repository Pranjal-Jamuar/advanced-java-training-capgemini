package com.lpu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lpu.entity.Student;
import com.lpu.servicelayer.StudentService;

@Controller
public class MyController {
	@Autowired
	private StudentService service;

	@RequestMapping("/help")
	public String getHelp() {
		return "help.jsp";
	}

	@RequestMapping("/payment")
	public String proceedToPayment() {
		return "payment.jsp";
	}

	@RequestMapping("/data")
	public String sendData(Model model) {
		model.addAttribute("name", "More Srinivas");
		model.addAttribute("phone", 6281);
		return "display.jsp";
	}

	@RequestMapping("/mv")
	public ModelAndView sendData2(ModelAndView mv) {
		mv.addObject("name", "Keshav");
		mv.addObject("phone", 9999);
		mv.setViewName("display.jsp");
		return mv;
	}

	@RequestMapping("/reg")
	public ModelAndView regi(@RequestParam(value = "n") String name, @RequestParam(value = "p") String phone,
			@RequestParam(value = "e") String email) {

		ModelAndView mv = new ModelAndView();
		mv.addObject("name", name);
		mv.addObject("phone", phone);
		mv.addObject("email", email);
		mv.setViewName("display.jsp");
		return mv;

	}

	@RequestMapping("/reg2")
	public ModelAndView register2(@ModelAttribute Student student) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("name", student.getName());
		mv.addObject("phone", student.getPhone());
		mv.addObject("email", student.getEmail());
		mv.setViewName("display.jsp");
		return mv;

	}

	@RequestMapping("/saveStudent")
	public String save(@ModelAttribute Student student, Model model) {
		service.registerStudent(student);
		model.addAttribute("student", student);
		return "display.jsp";
	}
	@RequestMapping("/find")
	public String getStudent(@RequestParam("id") int id, Model model) {
		Student s = service.findById(id);
		if (s != null) {
			model.addAttribute("student", s);
			return "display.jsp";
		}
		return "notfound.jsp";

	}

}
