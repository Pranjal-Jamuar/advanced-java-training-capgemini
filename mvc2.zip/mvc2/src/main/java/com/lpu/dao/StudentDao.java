package com.lpu.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lpu.entity.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.PersistenceContext;

@Repository
public class StudentDao {
	@Autowired
	private EntityManagerFactory emf;

	public void saveStudent(Student student) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		if (student != null) {
			et.begin();
			em.persist(student);
			et.commit();
		}
	}
	public Student findById(int id) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		Student s=em.find(Student.class, id);
		if(s==null) {
			System.out.println("null hai bhai");
		}
		return s;
	}
}
