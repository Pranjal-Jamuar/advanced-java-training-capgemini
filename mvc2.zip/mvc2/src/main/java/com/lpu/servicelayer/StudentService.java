package com.lpu.servicelayer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lpu.dao.StudentDao;
import com.lpu.entity.Student;

import jakarta.transaction.Transactional;

@Service
public class StudentService {
	@Autowired
	private StudentDao dao;
	@Transactional
	public void registerStudent(Student student) {
		dao.saveStudent(student);
	}
	public Student findById(int id) {
		return dao.findById(id);
	}
}
