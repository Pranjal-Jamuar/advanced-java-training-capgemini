<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8" isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Form</title>
</head>
<body>

	<h2>Details:</h2>
	<form action="reg2">
		Name: <br> <input type="text" name="name" ><br>
		<br> Phone Number: <br> <input type="tel" name="phone" ><br>
		<br> Email: <br> <input type="email" name="email"><br>
		<br> <input type="submit" value="Register">
	</form>
</body>
</html>