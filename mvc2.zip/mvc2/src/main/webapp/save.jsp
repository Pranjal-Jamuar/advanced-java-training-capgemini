<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"
	isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<form action="saveStudent">
	Name: <input type="text" name="name"><br><br>
	Phone Number: <input type="text" name="phone"><br><br>
	Email: <input type="text" name="email"><br><br>
	<input type="submit" value="register">
	</form>

</body>
</html>