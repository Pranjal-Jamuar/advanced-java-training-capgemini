<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"
    isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1>name: ${student.name}</h1>
<h1>phone: ${student.phone}</h1>
<h1>email: ${student.email}</h1>

</body>
</html>